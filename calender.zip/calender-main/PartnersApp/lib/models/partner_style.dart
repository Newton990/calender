enum PartnerStyle { masculine, feminine }
